/**
 * Created by peiyulin on 16/8/27.
 */
function gosearch() {
    alert("searching....");
}